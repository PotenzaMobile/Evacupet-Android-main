package com.evacupet.interfaceHelper;

import com.parse.ParseObject;

public interface AddLocationClick {
    void itemClick(ParseObject data,int flag);
}
