package com.evacupet.interfaceHelper;

import com.parse.ParseObject;

public interface EvacuationCenterClick {
    void itemClick(String centerId, String lat, String myLong);
}
