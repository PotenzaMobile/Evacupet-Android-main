package com.evacupet.interfaceHelper;

import com.parse.ParseObject;

public interface FindLocationClick {
    void itemClick(int flag);
}
