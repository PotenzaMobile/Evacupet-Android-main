package com.evacupet.utility;

public class PassData {
    public static boolean status = false;
}
