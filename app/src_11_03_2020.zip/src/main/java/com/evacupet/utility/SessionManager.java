package com.evacupet.utility;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.Toast;


import com.evacupet.activity.LoginActivity;
import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseUser;

public class SessionManager {
    public static final String TAG = SessionManager.class.getSimpleName();
    private Context context;
    private static final String APP_PREF_NAME = "Evacuet";
    private SharedPreferences appPref;
    private SharedPreferences.Editor appPrefEditor;

    public SessionManager(Context context) {
        this.context = context;
        appPref = context.getSharedPreferences(APP_PREF_NAME, Context.MODE_PRIVATE);
        appPrefEditor = appPref.edit();
        appPrefEditor.apply();
    }

    public void saveUserDetail(String userName, String sessionToken) {
        appPrefEditor.putString(Constant.USERNAME, userName);
        appPrefEditor.putString(Constant.TOKEN, sessionToken);
        appPrefEditor.putBoolean(Constant.IS_LOGIN, true);
        appPrefEditor.commit();
    }

    public void setIsLogin() {
        appPrefEditor.putBoolean(Constant.IS_LOGIN, true);
        appPrefEditor.commit();
    }

    public boolean isLogin() {
        return appPref.getBoolean(Constant.IS_LOGIN, false);
    }

    public String getUserId() {
        return appPref.getString(Constant.TOKEN, "");
    }


    public void logout(String msg) {
        logoutAlert(msg);

    }

    private void sentToLoginScreen() {
        Intent intent = new Intent(context, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
    }

    private void logoutAlert(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
       // builder.setMessage("Are you sure to logout?");
        builder.setMessage(msg);
        builder.setCancelable(true);

        builder.setPositiveButton(
                "Ok",
                new DialogInterface.OnClickListener() {
                    public void onClick(final DialogInterface dialog, int id) {
                        ParseUser.logOutInBackground(new LogOutCallback() {
                            public void done(ParseException e) {
                                if (e == null) {
                                    // logOutSuccessful();
                                    appPrefEditor.clear();
                                    appPrefEditor.commit();
                                    sentToLoginScreen();
                                } else {
                                    //  somethingWentWrong();
                                    Toast.makeText(context, e.getMessage(), Toast.LENGTH_SHORT).show();
                                    dialog.cancel();
                                }
                            }
                        });
                    }
                });


        builder.setNegativeButton(
                "Cancel",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert1 = builder.create();
        alert1.show();

    }

    public void closeApp(){

    }

}
