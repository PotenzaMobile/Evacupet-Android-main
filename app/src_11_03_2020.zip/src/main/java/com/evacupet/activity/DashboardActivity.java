package com.evacupet.activity;

import android.Manifest;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.provider.ContactsContract;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;



import com.evacupet.R;
import com.evacupet.adapter.NewsListRecyclerViewAdapter;
import com.evacupet.interfaceHelper.FindLocationClick;
import com.evacupet.model.NewsModel;
import com.evacupet.utility.BaseUtility;
import com.evacupet.utility.DialogUtility;
import com.evacupet.utility.PassData;
import com.evacupet.utility.SessionManager;
import com.jkb.slidemenu.OnSlideChangedListener;
import com.jkb.slidemenu.SlideMenuLayout;
import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


abstract public class DashboardActivity extends AppCompatActivity {
    private static final String TAG = DashboardActivity.class.getSimpleName();
    private static final int YOUR_SELECT_PICTURE_REQUEST_CODE = 101;
    private static final int ZXING_CAMERA_PERMISSION = 102;
    SlideMenuLayout slideMenuLayout;
    ImageView ivLeftMenu;
    ImageView ivRightMenu;
    TextView tvHome;
    TextView tvProfile;
    TextView tvLocation;
    TextView tvAnimals;
    TextView tvReport;
    TextView tvSuggest;
    TextView tvDonate;
    TextView tvLogout;
    TextView tvCenterLocation;
    TextView tvNews;
    TextView tvEvtCenter;
    TextView tvTellYourFriends;
    TextView tvFindEvt;
    TextView titleName;
    TextView tvPrivacy;
    private Uri outputFileUri;
    private boolean doubleBackToExitPressedOnce = false;
    private FindLocationClick findLocationClick;
    private int findLocationFlag;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);
        initStatusBar();
        init();
    }

    @Override
    public void onBackPressed() {
        if (slideMenuLayout.isLeftSlideOpen() || slideMenuLayout.isRightSlideOpen()) {
            slideMenuLayout.closeLeftSlide();
            slideMenuLayout.closeRightSlide();
        } else {
            if (PassData.status) {
                DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                findLocationFlag = 2;
            } else {
                if (doubleBackToExitPressedOnce) {
                    super.onBackPressed();
                    finishAffinity();
                    return;
                }
                doubleBackToExitPressedOnce = true;
                Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            }
        }
    }



    private void init() {
        findLocationClick = new FindLocationClick() {
            @Override
            public void itemClick(int flag) {
                if (flag == 1) {
                    if (findLocationFlag == 1) {
                        slideMenuLayout.toggleLeftSlide();
                    } else if (findLocationFlag == 0) {
                        slideMenuLayout.toggleRightSlide();
                    } else {
                        onBackPressed();
                    }
                }
            }
        };
        slideMenuLayout = findViewById(R.id.mainSlideMenu);
        ivLeftMenu = findViewById(R.id.iv_leftMenu);
        ivRightMenu = findViewById(R.id.iv_rightMenu);
        tvHome = findViewById(R.id.tv_home);
        tvProfile = findViewById(R.id.tv_profile);
        tvLocation = findViewById(R.id.tv_location);
        tvAnimals = findViewById(R.id.tv_animals);
        tvSuggest = findViewById(R.id.tv_suggest);
        tvReport = findViewById(R.id.tv_report);
        tvLogout = findViewById(R.id.tv_logout);
        tvCenterLocation = findViewById(R.id.tv_center_location);
        tvNews = findViewById(R.id.tv_news);
        tvEvtCenter = findViewById(R.id.tv_evt_center);
        tvFindEvt = findViewById(R.id.tv_find_evt);
        tvTellYourFriends = findViewById(R.id.tv_tell_your_friends);
        titleName = findViewById(R.id.title_name);
        tvDonate = findViewById(R.id.tv_donate);
        tvPrivacy = findViewById(R.id.tv_privacy);

        ivLeftMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                    findLocationFlag = 1;
                } else {
                    slideMenuLayout.toggleLeftSlide();
                }
            }
        });
        ivRightMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                    findLocationFlag = 0;
                } else {
                    slideMenuLayout.toggleRightSlide();
                }

            }
        });
        tvAnimals.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentLeftSide(getString(R.string.animals), AnimalsActivity.class);

                }
            }
        });
        tvCenterLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentRightSide(getString(R.string.center_location),CenterLocationActivity.class);

                }
            }
        });
        tvEvtCenter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentRightSide(getString(R.string.evacuation_center),EvacuationCenterActivity.class);

                }
            }
        });
        tvFindEvt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentRightSide(getString(R.string.find_evacuation),FindEvacationActivity.class);

                }
            }
        });
        tvSuggest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentLeftSide(getString(R.string.suggest_a_change), SuggestActivity.class);

                }
            }
        });
        tvDonate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentLeftSide(getString(R.string.donate), DonateActivity.class);

                }
            }
        });

        tvPrivacy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.evacu.pet/privacy/"));
                startActivity(browserIntent);
            }
        });

        tvReport.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentRightSide(getString(R.string.report_an_emergency),ReportEmergencyActivity.class);

                }
            }
        });
        tvHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentLeftSide(getString(R.string.profile), HomeActivity.class);

                }
            }
        });


        tvProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentLeftSide(getString(R.string.profile), ProfileActivity.class);
                }
            }
        });
        tvLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (PassData.status) {
                    DialogUtility.EvacuationProgressAlert(DashboardActivity.this, findLocationClick);
                } else {
                    sentIntentLeftSide(getString(R.string.profile), AnimalLocationActivity.class);

                }
            }
        });
        tvLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new SessionManager(DashboardActivity.this).logout(getString(R.string.logout_msg));
            }
        });

        slideMenuLayout.addOnSlideChangedListener(new OnSlideChangedListener() {
            @Override
            public void onSlideChanged(SlideMenuLayout slideMenu, boolean isLeftSlideOpen, boolean isRightSlideOpen) {
                Log.d(TAG, "onSlideChanged:isLeftSlideOpen=" + isLeftSlideOpen + ":isRightSlideOpen=" + isRightSlideOpen);
            }
        });

        tvTellYourFriends.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "EvacuPet");
                    String shareMessage = "Check it out! Evac-U-Pet is a free app that helps coordinate volunteers with those in need of assistance for their pets during emergency animal evacuations! For iOS Platform ";
                    shareMessage = shareMessage + "https://apps.apple.com/us/app/evacupet/id1420349072?ls=1"+" For Android Platform "+"https://play.google.com/store/apps/details?id=com.evacupet&hl=en";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {
                    //e.toString();
                }
            }
        });

    }

    private void initStatusBar() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.KITKAT) return;
        int flag_translucent_status = WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;
        getWindow().setFlags(flag_translucent_status, flag_translucent_status);
    }

    private void sentIntentLeftSide(String title, Class<?> cls){
        titleName.setText(title);
        slideMenuLayout.toggleLeftSlide();
        Intent intent = new Intent(this,cls);
        startActivity(intent);
    }
    private void sentIntentRightSide(String title, Class<?> cls){
        titleName.setText(title);
        slideMenuLayout.toggleRightSlide();
        Intent intent = new Intent(this,cls);
        startActivity(intent);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.e(TAG, "data = " + data);
        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == YOUR_SELECT_PICTURE_REQUEST_CODE) {
                onImageSuccess(data);
            }
        }
    }

    abstract public void onImageSuccess(Intent data);

    public Uri imageInit() {
        outputFileUri = new BaseUtility().checkAndRequestPermissions(this);
        return outputFileUri;

    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case ZXING_CAMERA_PERMISSION: {
                Map<String, Integer> perms = new HashMap<>();
                // Initialize the map with both permissions
                perms.put(Manifest.permission.CAMERA, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.READ_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);
                perms.put(Manifest.permission.WRITE_EXTERNAL_STORAGE, PackageManager.PERMISSION_GRANTED);

                // Fill with actual results from user
                if (grantResults.length > 0) {
                    for (int i = 0; i < permissions.length; i++)
                        perms.put(permissions[i], grantResults[i]);
                    // Check for both permissions
                    if (perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED && perms.get(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                            && perms.get(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {

                        outputFileUri = new BaseUtility().openImageIntent(this);

                    } else {
                        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.READ_EXTERNAL_STORAGE) || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) || ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.CAMERA)) {
                            new BaseUtility().showDialogOK(DashboardActivity.this, "Camera Permission required for this action",
                                    new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            switch (which) {
                                                case DialogInterface.BUTTON_POSITIVE:
                                                    outputFileUri = new BaseUtility().checkAndRequestPermissions(DashboardActivity.this);
                                                    break;
                                                case DialogInterface.BUTTON_NEGATIVE:
                                                    break;
                                            }
                                        }
                                    });
                        } else {
                            Toast.makeText(this, "Go to settings and enable permissions", Toast.LENGTH_LONG)
                                    .show();
                        }
                    }
                }
            }
        }
    }
}